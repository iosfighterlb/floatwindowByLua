//
//  AppDelegate.h
//  InstallWithStaticFramework
//
//  Created by junzhan on 15/11/5.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <wax/wax.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

