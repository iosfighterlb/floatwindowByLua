//
//  AppDelegate.m
//  InstallWithStaticFramework
//
//  Created by junzhan on 15/11/5.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//
//  lua 语法:
//  http://www.codingnow.com/2000/download/lua_manual.html
//
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    wax_start(nil, nil);
    wax_runLuaString("print('wax hello world')");
    wax_runLuaFile("ViewController.lua");
    
    return YES;
}

@end



