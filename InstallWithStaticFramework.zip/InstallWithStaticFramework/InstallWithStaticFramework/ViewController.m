//
//  ViewController.m
//  InstallWithStaticFramework
//
//  Created by junzhan on 15/11/5.
//  Copyright © 2015年 test.jz.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end
