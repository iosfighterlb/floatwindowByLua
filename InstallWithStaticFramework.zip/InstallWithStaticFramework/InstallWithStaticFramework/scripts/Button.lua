-- simple interface setting.  reference :https://github.com/alibaba/wax

waxClass{"Button", UIButton}


function drawRect(self,rect)

    self.super:drawRect(rect)

    print("customer button !")
end


-- 触摸事件.

function touchesBegan_withEvent(self,touches,event)

    print("Touch begins")

end


function touchesMoved_withEvent(self,touches,event)

    print("Touch move")
    
    touch = touches:anyObject();
    
    layer = self:superview():layer():sublayers()[1]         -- 记得lua中的数组为1开始

    -- layer.position = touch:locationInView(self:superview())   -- position 无效

    --layer:setPosition(touch:locationInView(self:superview()))

    -- print(touch:locationInView(self:superview()))

    self:setCenter(touch:locationInView(self:superview()))      -- 需要常用setCenter方法

end


function touchesEnded_withEvent(self,touches,event)

    print("Touch end")
    
    self:moveToEdge()

end



function moveToEdge(self)               -- 空方法也要加一个self上去
    
    if (self:center().x <= self:superview():bounds().width*0.5)
    then
    
        UIView:animateWithDuration_animations(0.7, toblock(
                                                           function()
                                                                self:setCenter(CGPoint(self:bounds().width*0.5, self:center().y))
                                                           end
                                                           )
                                              )
    else
   
        UIView:animateWithDuration_animations(0.7, toblock(
                                                           function()
                                                                local rightwidth = self:superview():bounds().width - self:bounds().width*0.5
                                                                self:setCenter(CGPoint(rightwidth, self:center().y))
                                                           end
                                                           )
                                              )
    end
end



