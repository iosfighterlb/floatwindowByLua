require "Button"

waxClass{"ViewController"}


function viewDidLoad(self)
    
    helloButton = Button:initWithFrame(CGRect(0, 0, 40, 40))
    helloButton:setBackgroundColor(UIColor:grayColor())
    
    helloButton:layer():setMasksToBounds(true)                  -- 获取属性的方法
    helloButton:layer():setCornerRadius(20.0)
    
    print("x = " .. helloButton:frame().x)                      -- 更便捷获取某些属性

    local image = UIImage:imageNamed("onion.png");
    helloButton:setImage_forState(image,UIControlStateNormal)   -- 一个以上的变量用_

    self:view():addSubview(helloButton)
    helloButton:setCenter(self:view():center())                 -- 更顺序性

end


