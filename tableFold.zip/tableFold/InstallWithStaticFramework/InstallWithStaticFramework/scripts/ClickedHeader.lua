-- simple interface setting.

waxClass{"ClickedHeader", UITableViewHeaderFooterView}


function initWithFrame(self, frame)

    self.super:initWithReuseIdentifier("headerReuseIdentifier")
    
    if(self)
    then
        self:setFrame(frame)
        
        print("can it push this")
        
        pressButton = UIButton:buttonWithType(UIButtonTypeCustom)
        pressButton:setFrame(frame)
        pressButton:setBackgroundColor(UIColor:lightGrayColor())
        pressButton:setTitle_forState("test",UIControlStateNormal)
        
        pressButton:addTarget_action_forControlEvents(self,"buttonClick",UIControlEventTouchUpInside)
        pressButton:setTag(100)
        
        self:contentView():addSubview(pressButton)
    end
    
    return self

end



function buttonClick(sender)
    
    print("buttonClick")
   
end



function initWithFrame_andReuseIdentifier_andTarget_andAction_andTag_andTitle(self, frame, reuseIdentifier, target, sel, tag, title)
    
    self.super:initWithReuseIdentifier(reuseIdentifier)
    
    if (self)
    then
        self:setFrame(frame)
    
        pressButton = UIButton:buttonWithType(UIButtonTypeCustom)
        pressButton:setFrame(frame)
        pressButton:setBackgroundColor(UIColor:lightGrayColor())
        pressButton:setTitle_forState(title,UIControlStateNormal)
        
        pressButton:addTarget_action_forControlEvents(target,sel,UIControlEventTouchUpInside)
        pressButton:setTag(tag)
        
        self:contentView():addSubview(pressButton)
    end
    
    return self
end






















