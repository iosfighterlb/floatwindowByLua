waxClass{"ViewController", protocols = {"UITableViewDelegate","UITableViewDataSource"}}


function init(self)
    self.super:init()
    
    return self
end


function viewDidLoad(self)

    -- 较复杂的表结构
    -- http://blog.csdn.net/silscorige/article/details/7759705
    
    arr = {
        ["魏"]={
            "张辽",
            "李典",
            "曹洪"
        },
        
        ["蜀"]={
            "关羽",
            "张飞",
            "赵云"
        },
        
        ["吴"]={
            "周瑜",
            "鲁肃",
            "黄盖"
        }
    }
    
    self.dataArr = {}
    
    for k in pairs(arr) do
        
        local tempArr = {}
        
        table.insert(tempArr, {["FOLD_STATE"]=1})
        table.insert(tempArr, arr[k])
        
        table.insert(self.dataArr,tempArr)
    end


    print("-------------------------------")


    for k in pairs(self.dataArr) do
    
        print(k)
        print(self.dataArr[k])
    
        for key, val in pairs(self.dataArr[k]) do
        
            if (key == 1)
                then
                print("FOLD_STATE is :"..val["FOLD_STATE"])
            
                elseif (key == 2)
                then
                for lastkey in pairs(val) do
                    print("the inner is : "..val[lastkey])
                end
            end
        end
        
    end


    self.tableview = UITableView:alloc():initWithFrame_style(UIScreen:mainScreen():bounds(),UITableViewStylePlain)

    self.tableview:setDelegate(self)
    self.tableview:setDataSource(self)
    self:view():addSubview(self.tableview)

    footer = UIView:alloc():initWithFrame(CGRect(0, 0, 0, 0))
    self.tableview:setTableFooterView(footer)
end





-- DataSource && Delegate.
-------------
function numberOfSectionsInTableView(self, tableView)
    
    return #self.dataArr
end


function tableView_numberOfRowsInSection(self, tableView, section)
    
    local sectionDic = self.dataArr[section+1]
    
    if (sectionDic[1]["FOLD_STATE"] == 1)
    then
        return 0
    else
        return #sectionDic[2]
    end
    
end


function tableView_heightForHeaderInSection(self, tableView, section)

    return 44
end



function tableView_cellForRowAtIndexPath(self, tableView, indexPath)
    
    local identifier = "TableViewFoldControllerCell"
    local cell = tableView:dequeueReusableCellWithIdentifier(identifier) or
    UITableViewCell:initWithStyle_reuseIdentifier(UITableViewCellStyleDefault, identifier)


    local cellDic = self.dataArr[indexPath:section()+1]
    local cellArr = cellDic[2]
    
    cell:textLabel():setText(cellArr[indexPath:row()+1])

    return cell
    
end



function tableView_viewForHeaderInSection(self, tableView, section)

    local title = nil
    local viewHeadArr = {}
    
    for k in pairs(arr) do
        
        table.insert(viewHeadArr, k)
    end

    pressHedaer = UIButton:buttonWithType(UIButtonTypeCustom)
    pressHedaer:setFrame(CGRect(0,0,UIScreen:mainScreen():bounds().width,44))
    pressHedaer:setBackgroundColor(UIColor:grayColor())
    pressHedaer:setTitle_forState(viewHeadArr[section+1],UIControlStateNormal)
    pressHedaer:setTag(section+1)
    
    pressHedaer:addTarget_action_forControlEvents(self,"buttonClicked:",UIControlEventTouchUpInside)
    
    return pressHedaer

end


function buttonClicked(self,button)
    
    print("-----ButtonClicked!-----")
    print(button:tag())
    
    for k in pairs(self.dataArr) do
        
        if (k == button:tag())
        then
        
            --print(self.dataArr[k][1]["FOLD_STATE"])
            
            if (self.dataArr[k][1]["FOLD_STATE"] == 1)
            then
                self.dataArr[k][1]["FOLD_STATE"] = 0
            else
                self.dataArr[k][1]["FOLD_STATE"] = 1
            end
            
        end
    end

    local indexs = NSIndexSet:indexSetWithIndex(button:tag()-1)

    self.tableview:reloadSections_withRowAnimation(indexs,UITableViewRowAnimationFade)
    
end







